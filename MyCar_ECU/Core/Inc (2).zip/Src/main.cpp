#include "stm32f0xx.h"

#include <cstdint>
#include <cstdio>

#include "hw/Clock.hpp"
#include "hw/Timebase.hpp"
#include "hw/BoardPins.hpp"
#include "hw/Gpio.hpp"
#include "hw/Uart.hpp"

#include "app/MotorDriver.hpp"
#include "app/Lights.hpp"
#include "sensors/UltrasonicSensor.hpp"

static MotorDriver motor;
static Lights lights;

static UltrasonicSensor usFront(
    BoardPins::US_TRIG_PORT, BoardPins::US_TRIG_PIN,
    BoardPins::US_ECHO_PORT, BoardPins::US_ECHO_PIN);

static UltrasonicSensor usRear(
    BoardPins::US_REAR_TRIG_PORT, BoardPins::US_REAR_TRIG_PIN,
    BoardPins::US_REAR_ECHO_PORT, BoardPins::US_REAR_ECHO_PIN);

static uint8_t speedPct = 40;


static volatile bool sensorShotReq = false;
static bool sensorsEnabled = false;
static bool sensorBusy = false;
static uint32_t nextSensorTickMs = 0;


static uint32_t loopMs = 0;


static constexpr uint32_t SENSOR_PERIOD_MS = 200;

static void setSpeed(uint8_t pct)
{
    if (pct > 100) pct = 100;
    speedPct = pct;
    motor.setSpeedPercent(speedPct);

    char buf[24];
    std::snprintf(buf, sizeof(buf), "SPD=%u\n", (unsigned)speedPct);
    Uart::write(buf);
}

static void stopAll()
{
    motor.stop();
    Uart::write("M=STOP\n");
}

static void sendDistances()
{
    uint32_t f = 0, r = 0;
    const bool okF = usFront.measureOnce(f);
    const bool okR = usRear.measureOnce(r);

    char buf[64];
    std::snprintf(buf, sizeof(buf),
                  "D F=%ld R=%ld\n",
                  okF ? (long)f : -1L,
                  okR ? (long)r : -1L);
    Uart::write(buf);
}

int main()
{
    Clock::init48MHz_HSI48();
    Timebase::init();


    Uart::init(115200);
    Uart::write("BOOT\n");


    motor.init();
    motor.enable();

    lights.init();
    lights.setHeadlight(false);
    lights.setStoplight(false);

    usFront.init();
    usRear.init();

    setSpeed(40);
    stopAll();


    loopMs = 0;
    nextSensorTickMs = loopMs + SENSOR_PERIOD_MS;

    while (1)
    {

        uint8_t b = 0;
        if (Uart::readByte(b))
        {
            if      (b == 'H') { lights.setHeadlight(true);  Uart::write("HL=1\n"); }
            else if (b == 'h') { lights.setHeadlight(false); Uart::write("HL=0\n"); }
            else if (b == 'S') { lights.setStoplight(true);  Uart::write("SL=1\n"); }
            else if (b == 's') { lights.setStoplight(false); Uart::write("SL=0\n"); }


            else if (b >= '0' && b <= '9')
            {
                setSpeed((uint8_t)(b - '0') * 10);
            }


            else if (b == 'F') { motor.forward();   Uart::write("M=F\n"); }
            else if (b == 'B') { motor.back();      Uart::write("M=B\n"); }
            else if (b == 'L') { motor.spinLeft();  Uart::write("M=L\n"); }
            else if (b == 'R') { motor.spinRight(); Uart::write("M=R\n"); }
            else if (b == 'X') { stopAll(); }


            else if (b == 'g')
            {

                if (!sensorBusy) sensorShotReq = true;
                Uart::write("G=ACK\n");
            }

            else if (b == 'E')
            {
                sensorsEnabled = true;

                nextSensorTickMs = loopMs + SENSOR_PERIOD_MS;
                Uart::write("SNS=1\n");
            }

            else if (b == 'e')
            {
                sensorsEnabled = false;
                Uart::write("SNS=0\n");
            }
            else
            {
                Uart::write("RX=?\n");
            }
        }


        if (!sensorBusy)
        {
            const bool doShot = sensorShotReq;
            const bool doPeriodic = sensorsEnabled && ((int32_t)(loopMs - nextSensorTickMs) >= 0);

            if (doShot || doPeriodic)
            {
                sensorShotReq = false;
                sensorBusy = true;

                sendDistances();


                nextSensorTickMs = loopMs + SENSOR_PERIOD_MS;

                sensorBusy = false;
            }
        }

        Timebase::delayMs(2);
        loopMs += 2;
    }
}
